const mysql = require('mysql');

// Configurar a conexão com o banco de dados
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: ''
});

connection.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao servidor MySQL:', err);
        return;
    }
    console.log('Conexão ao servidor MySQL estabelecida com sucesso!');

    // Verificar se o banco de dados 'estudantes' existe
    connection.query(`CREATE DATABASE IF NOT EXISTS estudantes`, (error) => {
        if (error) {
            console.error('Erro ao verificar/criar o banco de dados:', error);
            return;
        }
        console.log('Banco de dados "estudantes" verificado/criado com sucesso!');

        // Agora que o banco de dados está criado (ou já existia), conecte-se a ele
        connection.changeUser({ database: 'estudantes' }, (err) => {
            if (err) {
                console.error('Erro ao conectar ao banco de dados "estudantes":', err);
                return;
            }
            console.log('Conexão ao banco de dados "estudantes" estabelecida com sucesso!');

            // Criar a tabela 'students' se ainda não existir
            connection.query(`CREATE TABLE IF NOT EXISTS students (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                course VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )`, (error) => {
                if (error) {
                    console.error('Erro ao verificar/criar a tabela:', error);
                    return;
                }
                console.log('Tabela "students" verificada/criada com sucesso!');
                
                // Não encerrar a conexão aqui
            });
        });
    });
});

// Classe para representar o modelo de estudante
class Student {
    constructor(name, course, email, phone) {
        this._name = name;
        this._course = course;
        this._email = email;
        this._phone = phone;
        this._created_at = null;
        this._updated_at = null;
    }

    // Métodos get e set para acessar e modificar os atributos
    get name() {
        return this._name;
    }

    set name(name) {
        this._name = name;
    }

    get course() {
        return this._course;
    }

    set course(course) {
        this._course = course;
    }

    get email() {
        return this._email;
    }

    set email(email) {
        this._email = email;
    }

    get phone() {
        return this._phone;
    }

    set phone(phone) {
        this._phone = phone;
    }

    get created_at() {
        return this._created_at;
    }

    get updated_at() {
        return this._updated_at;
    }

    // Método para salvar um novo estudante no banco de dados
    save(callback) {
        const { name, course, email, phone } = this;
        const createdAt = new Date().toISOString();
        connection.query('INSERT INTO students (name, course, email, phone, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)', [name, course, email, phone, createdAt, createdAt], (error, results) => {
            if (error) {
                console.error('Erro ao salvar o estudante:', error);
                callback(error, null);
                return;
            }
            console.log('Estudante salvo com sucesso!');
            callback(null, results.insertId);
        });
    }

    // Método para buscar todos os estudantes no banco de dados
    static getAll(callback) {
        connection.query('SELECT * FROM students', (error, results) => {
            if (error) {
                console.error('Erro ao buscar os estudantes:', error);
                callback(error, null);
                return;
            }
            console.log('Estudantes encontrados com sucesso!');
            callback(null, results);
        });
    }

    // Método para buscar um estudante pelo ID no banco de dados
    static getById(id, callback) {
        connection.query('SELECT * FROM students WHERE id = ?', [id], (error, results) => {
            if (error) {
                console.error('Erro ao buscar o estudante:', error);
                callback(error, null);
                return;
            }
            console.log('Estudante encontrado com sucesso!');
            callback(null, results[0]);
        });
    }

    // Método para atualizar um estudante pelo ID
    static update(id, newData, callback) {
        // Lógica para atualizar os detalhes do estudante com o ID fornecido
        const { name, course, email, phone } = newData;
        const updatedAt = new Date().toISOString();
        connection.query(
            'UPDATE students SET name = ?, course = ?, email = ?, phone = ?, updated_at = ? WHERE id = ?',
            [name, course, email, phone, updatedAt, id],
            (error, results) => {
                if (error) {
                    console.error('Erro ao atualizar o estudante:', error);
                    callback(error, null);
                    return;
                }
                console.log('Estudante atualizado com sucesso!');
                callback(null, results.changedRows);
            }
        );
    }

    // Método para atualizar informações de um estudante no banco de dados
    update(callback) {
        const { id, name, course, email, phone } = this;
        const updatedAt = new Date().toISOString();
        connection.query('UPDATE students SET name = ?, course = ?, email = ?, phone = ?, updated_at = ? WHERE id = ?', [name, course, email, phone, updatedAt, id], (error, results) => {
            if (error) {
                console.error('Erro ao atualizar o estudante:', error);
                callback(error, null);
                return;
            }
            console.log('Estudante atualizado com sucesso!');
            callback(null, results.changedRows);
        });
    }

    // Método para excluir um estudante do banco de dados
    static deleteById(id, callback) {
        connection.query('DELETE FROM students WHERE id = ?', [id], (error, results) => {
            if (error) {
                console.error('Erro ao excluir o estudante:', error);
                callback(error, null);
                return;
            }
            console.log('Estudante excluído com sucesso!');
            callback(null, results.affectedRows);
        });
    }

    // Método para excluir um estudante do banco de dados
    delete(callback) {
        const { id } = this;
        connection.query('DELETE FROM students WHERE id = ?', [id], (error, results) => {
            if (error) {
                console.error('Erro ao excluir o estudante:', error);
                callback(error, null);
                return;
            }
            console.log('Estudante excluído com sucesso!');
            callback(null, results.affectedRows);
        });
    }

    // Métodos para interagir com o banco de dados, como buscar, atualizar, excluir, etc.
}

module.exports = Student;