const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Student = require('../models/studentModel');

// Função para validar se os campos estão em branco
const validateFields = [
    body('name').notEmpty().withMessage('O campo nome é obrigatório'),
    body('course').notEmpty().withMessage('O campo curso é obrigatório'),
    body('email').notEmpty().withMessage('O campo email é obrigatório'),
    body('phone').notEmpty().withMessage('O campo telefone é obrigatório'),
];

// Rota para criar um novo estudante
router.post('/students', validateFields, (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(422).json({ errors: errors.array() });
    }

    const { name, course, email, phone } = req.body;
    const student = new Student(name, course, email, phone);

    student.save((error, studentId) => {
        if (error) {
            return res.status(500).json({ error: 'Erro ao salvar o estudante' });
        }

        // Criar o objeto de resposta no formato desejado
        const responseData = {
            status: 200,
            message: 'Estudante cadastrado com sucesso',
            student: {
                id: studentId,
                name: name,
                course: course,
                email: email,
                phone: phone,
                created_at: student.created_at,
                updated_at: student.updated_at
            }
        };

        res.status(201).json(responseData);
    });
});

// Rota para listar todos os estudantes
router.get('/students', (req, res) => {
    Student.getAll((error, student) => {
        if (error) {
            return res.status(500).json({ error: 'Erro ao buscar os estudantes' });
        }
        
        // Criar o objeto de resposta no formato desejado
        const students = {
            status: 200,
            student: student
        };

        res.json(students);
    });
});

//======================

// Defina a rota para exibir os detalhes do estudante pelo ID
router.get('/students/:id/edit', (req, res) => {
    const id = req.params.id;
    Student.getById(id, (error, student) => {
        if (error) {
            return res.status(500).json({ error: 'Erro ao buscar o estudante' });
        }
        if (!student) {
            return res.status(404).json({ error: 'Estudante não encontrado' });
        }
        const students = {
            status: 200,
            student: student
        };
        res.json(students);
    });
});

// Rota para atualizar os detalhes de um estudante pelo ID
router.put('/students/:id/edit', (req, res) => {
    const id = req.params.id;
    const { name, course, email, phone } = req.body;

    // Chame o método update do modelo Student para salvar as alterações no banco de dados
    Student.update(id, { name, course, email, phone }, (error, changedRows) => {
        if (error) {
            // Se houver um erro, envie uma mensagem de erro
            return res.status(500).json({ message: 'Erro ao atualizar o estudante' });
        }
        if (changedRows === 0) {
            // Se nenhum registro foi alterado, o estudante não foi encontrado
            return res.status(404).json({ message: 'Estudante não encontrado' });
        }
        // Se a atualização for bem-sucedida, envie uma mensagem de sucesso
        res.status(200).json({ message: 'Estudante atualizado com sucesso' });
    });
});

//======================

// Rota para excluir um estudante pelo ID
router.delete('/students/:id/delete', (req, res) => {
    const id = req.params.id;
    Student.deleteById(id, (error, numRowsAffected) => {
        if (error) {
            return res.status(500).json({ error: 'Erro ao excluir o estudante' });
        }
        if (numRowsAffected === 0) {
            return res.status(404).json({ error: 'Estudante não encontrado' });
        }
        res.json({ message: 'Estudante excluído com sucesso' });
    });
});

module.exports = router;